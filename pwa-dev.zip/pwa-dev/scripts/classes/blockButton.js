// -------------------------------------------
// -- BlockButton Class/Methods
function BlockButton( cwsRenderObj, blockObj )
{
    var me = this;

    me.cwsRenderObj = cwsRenderObj;
	me.blockObj = blockObj;
	me.actionObj;

	// Tabs Related HTMLs
	me.divTabsContainer = ` <div class="tab_fs" /> `;
	me.divTabsTargetContainer = ` <div class="tab_fs__container" /> `;
	me.ulTabsHead = ` <ul class="tab_fs__head" /> `;
	me.divHeadIcon = ` <div class="tab_fs__head-icon" /> `;
	me.divHeadIconExp = ` <div class="tab_fs__head-icon_exp" style="cursor: pointer; pointer-events: none;" /> `;  // Quick Fix, but not good one
	me.divHeadTextSpan = ` <span /> `;
	me.ulTab2ndary = ` <ul class="2ndary" style="display:none" /> `;
	me.liTab2ndary = ` <li class="2ndary" style="display:none" /> `;
	me.divTabsTargetElement = ` <div class="tab_fs__container-content" /> `;

	// =============================================
	// === TEMPLATE METHODS ========================

	me.initialize = function() {
		me.actionObj = new Action( me.cwsRenderObj, me.blockObj );
	};

	me.render = function( buttonsId, blockTag, passedData )
	{
		if ( buttonsId )
		{			
			// 'MainTab' type block - tab buttons   VS.   Buttons inside the block
			if ( me.blockObj.blockType === FormUtil.blockType_MainTab )
			{
				// STEP 1. MainTab case, blockDivTag has 2 main sections: 1. 
				var tabButtonsDivTag = me.createTabsBtnNContentTags( buttonsId, blockTag );
	

				// STEP 2. Main Render: block button tag generate
				for( var i = 0; i < buttonsId.length; i++ )
				{
					var btnId = buttonsId[ i ];
					me.renderBlockButton( btnId, tabButtonsDivTag, passedData );
					// No need to append since it was already created on 'createTabsBtnNContentTags'
				}
	
	
				// STEP 3. Setup the tab click for opening tab content area
				FormUtil.setUpEntryTabClick( tabButtonsDivTag ); //expIconTag
	
				// Click on 1st/Last-Recorded tab.
				setTimeout( function() 
				{
					tabButtonsDivTag.find( 'li:first' ).click();
				}, 100 );
				
			}
			else
			{
				// STEP 2. Main Render: block button tag generate
				for( var i = 0; i < buttonsId.length; i++ )
				{
					var btnId = buttonsId[ i ];
					var btnTag = me.renderBlockButton( btnId, blockTag, passedData );
					blockTag.append( btnTag );
				}
			}
		}
	};


	// =============================================
	// === OTHER INTERNAL/EXTERNAL METHODS =========

	me.createTabsBtnNContentTags = function( buttonsId, blockTag )
	{
		// Tab Button div section & Tab Content div section create
		var btnTabsContainerTag = $( me.divTabsContainer );
		var btnContentContainerTag = $( me.divTabsTargetContainer );

		blockTag.append( btnTabsContainerTag );
		blockTag.append( btnContentContainerTag );


		// Main Tab Part
		var btnTabsUlTag = $( me.ulTabsHead );
		btnTabsContainerTag.append( btnTabsUlTag );

		var expIconTag = $( me.divHeadIconExp );
		btnTabsContainerTag.append( expIconTag );

		// TODO: Add to on tab click event..


		btnTabsUlTag.css( '--tabs', ( buttonsId.length > 0 ) ? buttonsId.length : 1 );

		// SETUP EMPTY PLACE HOLDERS FOR TABS + TAB-CONTENT (pregenerated)
		for( var i = 0; i < buttonsId.length; i++ )
		{
			// MAIN DISPLAY TAB
			var liTabTag = $( '<li class="primary" />' );
			var dvTabContentTag = $( me.divHeadIcon );
			var spTabTextTag = $( me.divHeadTextSpan );
			var dvContentTag = $( me.divTabsTargetElement );

			liTabTag.attr( 'rel', buttonsId[ i ] );
			dvTabContentTag.attr( 'rel', buttonsId[ i ] );
			spTabTextTag.attr( 'rel', buttonsId[ i ] );

			dvContentTag.attr( 'tabButtonId', buttonsId[ i ] );
			
			btnTabsUlTag.append( liTabTag );
			liTabTag.append( dvTabContentTag );
			liTabTag.append( spTabTextTag );
			btnContentContainerTag.append( dvContentTag );

			if ( btnTabsUlTag )
			{
				// SECONDARY DISPLAY TAB (hidden, but shown for small screen layout)
				let ulTabTag = $( me.ulTab2ndary );

				for( var a = 0; a < buttonsId.length; a++ )
				{
					if ( a !== i )
					{
						var li2ndaryTabTag = $( me.liTab2ndary );
						var dv2ndaryTabContentTag = $( me.divHeadIcon );
						var sp2ndaryTabTextTag = $( me.divHeadTextSpan );

						li2ndaryTabTag.attr( 'rel', buttonsId[ a ] );
						dv2ndaryTabContentTag.attr( 'rel', buttonsId[ a ] );
						sp2ndaryTabTextTag.attr( 'rel', buttonsId[ a ] );

						li2ndaryTabTag.append( dv2ndaryTabContentTag );
						li2ndaryTabTag.append( sp2ndaryTabTextTag );
						ulTabTag.append( li2ndaryTabTag );
					}
				}

				btnTabsUlTag.find( 'li.primary[rel=' + buttonsId[ i ] + ']' ).append( ulTabTag );
			}
		}	
		
		return btnTabsContainerTag;
	};


	me.renderBlockButton = function( btnId, targetTag, passedData )
	{
		//var targetDivTag;  // target Div where the buttons will be added.
		var btnJson = FormUtil.getObjFromDefinition( btnId, ConfigManager.getConfigJson().definitionButtons );

		// For TabButtons Case, they are already generaeted with some html at this point...  Simply adding more details.
		var btnTag = me.generateBtnTag( btnJson, btnId, targetTag );
		
		// Block Button Click Setup
		me.setUpBtnClick( btnTag, btnJson, btnId, passedData );

		return btnTag;
	};


	me.generateBtnTag = function( btnJson, btnId, divTag )
	{
		var btnTag;

		if ( btnJson !== undefined )
		{
			if ( btnJson.buttonType === 'radioButton' )
			{
				btnTag = $( '<div style="padding:14px;" class=""><input type="radio" class="stayLoggedIn" style="width: 1.4em; height: 1.4em;">'
					+ '<span ' + FormUtil.getTermAttr( btnJson ) + ' style="vertical-align: top; margin-left: 5px; ">' + btnJson.defaultLabel + '</span></div>' );
			}
			else if ( btnJson.buttonType === 'imageButton' )
			{
				// New UI Tab Button
				if ( me.blockObj.blockType === FormUtil.blockType_MainTab )
				{
					var liTabTag = divTag.find( 'li[rel=' + btnId + ']' );
					var liDivTag = divTag.find( 'div[rel=' + btnId + ']' );
					var liSpanTag = divTag.find( 'span[rel=' + btnId + ']' );

					liDivTag.css( 'background', 'url(' + btnJson.imageSrc + ')' );
					liSpanTag.text( btnJson.defaultLabel );
					FormUtil.addTag_TermAttr( liSpanTag, btnJson );

					btnTag = liTabTag;
				}
				else
				{
					btnTag = $( '<div class="btnType ' + btnJson.buttonType + '"><img src="' + btnJson.imageSrc + '"></div>' );
				}
			}
			else if ( btnJson.buttonType === 'textButton' )
			{
				if ( me.blockObj.blockType === FormUtil.blockType_MainTabContent )
				{
					btnTag = $( '<div class="button primary button-full_width" />' );
				}
				else
				{
					btnTag = $( '<button ' + FormUtil.getTermAttr( btnJson ) + ' ranid="' + Util.generateRandomId() + '" class="button primary button-full_width ' + btnJson.buttonType + '" />' );
				}

				var btnContainerTag = $( '<div class="button__container" />' );
				var btnLabelTag = $( '<div ' + FormUtil.getTermAttr( btnJson ) + ' class="button-label" />' );

				btnTag.append( btnContainerTag );
				btnContainerTag.append( btnLabelTag );

				btnLabelTag.text( btnJson.defaultLabel );

			}
			else if ( btnJson.buttonType === 'listRightImg' )
			{
				btnTag = $( '<img src="' + ( btnJson.img ? btnJson.img : 'images/arrow_right.svg' ) + '" style="cursor: pointer;" ranid="' + Util.generateRandomId() + '" class="btnType ' + btnJson.buttonType + '" >' );
				btnTag.on( 'error', function (){
					$( this).attr( 'src', 'images/arrow_right.svg' );
					return false;
				});

				if ( divTag )
				{
					//console.customLog( svgStyle );
					btnTag.attr( 'width', '60px' ); // ( divTag.css( 'width' ) ? divTag.css( 'width' ) : '60px' ) ); //svgStyle.width
					btnTag.attr( 'height', '60px' ); // ( divTag.css( 'height' ) ? divTag.css( 'height' ) : '60px' ) );	//svgStyle.height
				}
			}
		}

		if ( btnTag === undefined )
		{
			var caseNA = ( btnId !== undefined && typeof btnId === 'string' ) ? btnId : "NA";
			btnTag = $( '<div class="btnType unknown">' + caseNA + '</div>' );
		}

		return btnTag;
	};


	me.setUpBtnClick = function( btnTag, btnJson, btnId, passedData )
	{
		if ( btnJson && btnTag )
		{
			if ( btnJson.onClick )
			{
				btnTag.click( function() 
				{
					if ( me.networkModeNotSupported( btnJson, ConnManagerNew.statusInfo.appMode ) )
					{
						AppModeSwitchPrompt.showInvalidNetworkMode_Dialog( ConnManagerNew.statusInfo.appMode, cwsRenderObj );
					}
					else
					{
						if ( me.blockObj.blockType === FormUtil.blockType_MainTab ) 
						{
							var blockDivTag = btnTag.closest( 'div.block' );
							var btnTargetParentTag = me.blockObj.blockTag.find( '.tab_fs__container-content[tabButtonId="' + btnId + '"]' );

							// TEMP: NOTE: For 'MainTab image button click', 
							//		We could have clear content on 'onClick' action list, but for now... do this as initial default action..
							btnTargetParentTag.empty();

							me.actionObj.handleClickActions( btnTag, btnJson.onClick, btnTargetParentTag, blockDivTag, undefined, passedData );
						}	
						else
						{
							//var blockDivTag = btnTag.closest( '.block' );
							// TODO: 'tab_fs__container-content' <-- TEMPORARY FIX <-- WILL NOT WORK WITH ALL BLOCK MODEL, BUT ONLY TAB BASED ONES.. 
							var blockDivTag = btnTag.closest( 'div.block' );
							var formDivSecTag = blockDivTag.find( '.formDivSec' );
	
							// NOTE: TRAN VALIDATION
							if( ValidationUtil.checkFormEntryTagsData( formDivSecTag ) )
							{				
								// TODO: ACTIVITY ADDING - Placed Activity Addition here - since we do not know which block is used vs displayed
								//	Until the button within block is used.. (We should limit to certain type of button to do this, actually.)
								ActivityUtil.addAsActivity( 'block', me.blockObj.blockJson, me.blockObj.blockId );

								me.actionObj.handleClickActions( btnTag, btnJson.onClick, me.blockObj.parentTag, blockDivTag, formDivSecTag, passedData );
							}
						}	
					}			
				});
			}
			else if( btnJson.onClickItem )
			{
				btnTag.click( function() 
				{
					//var btnTag = $( this );
					var blockDivTag = btnTag.closest( 'div.block' );
					var itemBlockTag = btnTag.closest( '.itemBlock' );
						
					if( ValidationUtil.checkFormEntryTagsData( itemBlockTag ) )
					{
						// TODO: ACTIVITY ADDING
						ActivityUtil.addAsActivity( 'block', me.blockObj.blockJson, me.blockObj.blockId );

						// display 'loading' image in place of click-img (assuming content will be replaced by new block)
						if ( btnJson.buttonType === 'listRightImg' )
						{
							// TODO: GREG <-- You can use .closest( '.---' ) instead
							var parentDiv = btnTag.parent().parent().parent().parent().parent()[0];

							for( var i = 0; i < parentDiv.children.length; i++ )
							{
								let tbl = parentDiv.children[i];

								if ( tbl != btnTag.parent().parent().parent().parent()[0] )
								{
									$( tbl ).css('opacity','0.4');
								}

							}

							var loadingTag = $( '<div class="loadingImg" style="display: inline-block; margin-left: 8px;"><img src="images/loading_small.svg"></div>' );
							btnTag.hide();
							btnTag.parent().append( loadingTag );
						} 

						var idx = btnTag.closest(".itemBlock").attr("idx");
						me.actionObj.handleItemClickActions( btnTag, btnJson.onClickItem, idx, blockDivTag, itemBlockTag, passedData );
						// , passedData ); <-- 'passedData' is not used anymore.
						//	It retrieves from DHIS/WebService (making retrieveByClientId call) (using clientId again..)
					}
				});
			}
		}
	}

	me.networkModeNotSupported = function( btnJson, appMode )
	{
		return ( btnJson.notSupportedMode 
			&& btnJson.notSupportedMode[ appMode.toLowerCase() ] );
	}

	/*
	me.renderBlockTabContent = function( tabContentTag, onClick )
	{
		if ( onClick && onClick.length > 0 )
		{
			var actionJsonArr = FormUtil.convertNamedJsonArr( onClick, ConfigManager.getConfigJson().definitionActions );
			var actionJson = Util.getFromList( actionJsonArr, 'openBlock', 'actionType' );

			if ( actionJson && actionJson.blockId !== undefined )
			{
				var blockJson = FormUtil.getObjFromDefinition( actionJson.blockId, ConfigManager.getConfigJson().definitionBlocks );

				// Create the block and render it.
				var newBlockObj = new Block( me.cwsRenderObj, blockJson, actionJson.blockId, tabContentTag, actionJson );
				newBlockObj.render();

				if ( actionJson.payloadConfig )
				{
					FormUtil.block_payloadConfig = actionJson.payloadConfig;
					FormUtil.setPayloadConfig( newBlockObj, actionJson.payloadConfig, ConfigManager.getConfigJson().definitionForms[ blockJson.form ] );
				}
				else
				{
					FormUtil.block_payloadConfig = '';
				}

			}
		}
	}
	*/

	me.getActionCases = function( objClick )
	{
		var ret = { show: [], hide: [] };

		for( var o = 0; o < objClick.length; o++ )
		{
			if ( objClick[ o].showCase )
			{
				for( var i = 0; i < objClick[ o].showCase.length; i++ )
				{
					if ( ! ( ret.show ).includes( objClick[ o].showCase[ i ] ) )
					{
						ret.show.push( objClick[ o].showCase[ i ] );
					}
				}
			}

			if ( objClick[ o].hideCase )
			{
				for( var i = 0; i < objClick[ o].hideCase.length; i++ )
				{
					if ( ! ( ret.hide ).includes( objClick[ o].hideCase[ i ] ) )
					{
						ret.hide.push( objClick[ o].hideCase[ i ] );
					}
				}

			}
		}

		return ret;

	}

	// -------------------------------
	
	me.initialize();
}